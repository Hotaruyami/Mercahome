var searchData=
[
  ['_7ecaixa',['~caixa',['../classcaixa.html#ae07ac19d0fb3e300c5c476eb5dd1fd20',1,'caixa']]],
  ['_7ecjtclients',['~cjtclients',['../classcjtclients.html#a3e60882c83ab3915c2deea48bdab4725',1,'cjtclients']]],
  ['_7eproducte',['~producte',['../classproducte.html#a36f2d1052fc243613f074ef6539dd517',1,'producte']]],
  ['_7eseccio',['~seccio',['../classseccio.html#a1211707b3dfeeddb41101cc8439b8805',1,'seccio']]],
  ['_7esuper',['~super',['../classsuper.html#ae056e76607348f045410264a3d9a8adb',1,'super']]]
];
