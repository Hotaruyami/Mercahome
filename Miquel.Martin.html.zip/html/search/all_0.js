var searchData=
[
  ['afegir_5fclient',['afegir_client',['../classcaixa.html#ac0d2f4629adaae920a2dbfe0b34677e6',1,'caixa']]],
  ['afegir_5festat',['afegir_estat',['../classcaixa.html#ac517916c32deab1298bb1ad1a8ff2be6',1,'caixa']]]
];
