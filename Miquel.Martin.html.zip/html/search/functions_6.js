var searchData=
[
  ['producte',['producte',['../classproducte.html#a2f70ad81bc664fea2154fda8df166017',1,'producte']]],
  ['productes_5fseccio',['productes_seccio',['../classsuper.html#a421b5c903c647c89b6ce5d0807d63ee6',1,'super']]]
];
