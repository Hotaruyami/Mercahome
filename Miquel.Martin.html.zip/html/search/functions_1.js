var searchData=
[
  ['caixadesti',['CaixaDesti',['../classsuper.html#ad1693febd14cd25e1ebed866c857d399',1,'super']]],
  ['consultar_5fproducte',['consultar_producte',['../classsuper.html#a28e26d0f2e5247d864730894b32717fe',1,'super']]],
  ['consultar_5fseccio',['consultar_seccio',['../classproducte.html#af8f300703088dc4cd73eb92b05628c56',1,'producte']]],
  ['consultar_5ftempsc',['consultar_tempsc',['../classproducte.html#aa0c8bb6d5f6b9af69a474f26e169e3c1',1,'producte']]]
];
