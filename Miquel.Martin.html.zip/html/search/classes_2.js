var searchData=
[
  ['seccio',['seccio',['../classseccio.html',1,'']]],
  ['super',['super',['../classsuper.html',1,'']]]
];
