var searchData=
[
  ['temps_5fde_5fcua',['temps_de_cua',['../classcjtclients.html#a77a263e573626dfff05703a3734dbca8',1,'cjtclients']]],
  ['temps_5fde_5fla_5fcua',['temps_de_la_cua',['../classcaixa.html#a7251a544853d87dcab6d6fc0138c1113',1,'caixa']]],
  ['tempsdespl',['TempsDespl',['../classsuper.html#a315020cc479d0b93ddcf714019a8629f',1,'super']]],
  ['tempspagament',['TempsPagament',['../classcjtclients.html#a0b9c97fa573ef7103ad2a530bb5ecc65',1,'cjtclients']]]
];
