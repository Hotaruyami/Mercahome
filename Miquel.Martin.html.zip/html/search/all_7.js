var searchData=
[
  ['seccio',['seccio',['../classseccio.html',1,'seccio'],['../classseccio.html#aa79341bd4a1009cea20250d4bee41e1f',1,'seccio::seccio()']]],
  ['simulaciocaixes',['SimulacioCaixes',['../classsuper.html#a097e100f430427a3844e831cc04f8310',1,'super']]],
  ['super',['super',['../classsuper.html',1,'super'],['../classsuper.html#ae4f7d66729aa3cc3f4abcb2e68c2fc70',1,'super::super()']]]
];
