var searchData=
[
  ['optim',['optim',['../classsuper.html#ab5d469b268e432e318f2fcc2a55cf640',1,'super']]]
];
