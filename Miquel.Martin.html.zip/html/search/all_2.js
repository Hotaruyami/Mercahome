var searchData=
[
  ['esborrar_5fclient',['esborrar_client',['../classcaixa.html#a4e8de94021d95ad038b653315b51e5e2',1,'caixa']]],
  ['escriure',['escriure',['../classcjtclients.html#a7285a9e18578a0556cee55919790aea0',1,'cjtclients::escriure()'],['../classproducte.html#a7c1ca15dbf8d6fdfd39b428a97d3fac4',1,'producte::escriure()']]],
  ['escriure_5fproducte',['escriure_producte',['../classsuper.html#a94bda43fb1db6ee5565cc6dd4293c1ac',1,'super']]],
  ['estat_5fcaixa',['estat_caixa',['../classcaixa.html#ab766335d9143095b70cd4169667b71a6',1,'caixa']]]
];
