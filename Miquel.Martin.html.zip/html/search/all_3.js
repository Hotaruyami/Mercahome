var searchData=
[
  ['llegir',['llegir',['../classcjtclients.html#a1b11e1fbe9ae02b847665428089616ce',1,'cjtclients::llegir()'],['../classproducte.html#a86e259f6c73fb246b9b2fecadf5d36c5',1,'producte::llegir()']]]
];
